<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {
    public function index()
    {
    	
        $this->load->view('user/user_home');
    }
   


public function login_home(){
    if($this->session->userdata('sess_id')){

        $this->load->view('user/user_login_home');
    }else
    {
          $this->load->view('exceptions/404');
    }       
}
public function login_home_(){
    if($this->session->userdata('sess_id')){
        $this->session->unset_userdata('pnr_no');
        $this->load->view('user/user_login_home');
    }else
    {
          $this->load->view('exceptions/404');
    }       
}

   public function login_process(){
    if(isset($_POST['emid']) && isset($_POST['pass'])){
        $emid=$_POST['emid'];
        $pass=$_POST['pass'];
        $this->load->model('user_model');
        $response=$this->user_model->login_process($emid,$pass);
        if($response=="failed")
        {
           
            echo "failed";
        }
        else{
             $this->session->set_userdata('sess_id',$response);
           
            echo "success";
           
        }
    }
    else{
        $this->load->view('exceptions/404');
    }
   }
 public function login()
    {
        $this->load->view('user/user_login');
    }
    public function register()
    {
        $this->load->view('user/user_register');
    }
 public function update_profile(){
    if(isset($_POST['email']) && isset($_POST['mobile']))
    {
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$ref_emid=$_POST['emid'];
$this->load->model('user_model');
$response=$this->user_model->update_profile($email,$mobile,$ref_emid);
if($response=="failed"){
    echo "failed";
}else if($response=="success"){
    echo "success";
}

    }else {
         $this->load->view('exceptions/404');
    }
 }
 public function change_password(){
    if(isset($_POST['current_emid']) && isset($_POST['current']) && isset($_POST['new'])){
        $current_emid=$_POST['current_emid'];
        $current=$_POST['current'];
        $new=$_POST['new'];
        $this->load->model('user_model');
        $response=$this->user_model->change_password($current_emid,$current,$new);
        if($response=="failed"){
echo "failed";
        }else if($response=="success"){
            echo "success";
        }

    }else{
      $this->load->view('exceptions/404');   
    }
 }
 public function pnr_process(){
if(isset($_POST['pnr_edit'])){
    $pnr=$_POST['pnr_edit'];
    $this->load->model('user_model');
    $response=$this->user_model->pnr_process($pnr);
    if($response=="failed"){
        echo "failed";
    }else if($response=="success"){
         $this->session->set_userdata('pnr_no',$pnr);
        echo "success";

    }
 }else{
      $this->load->view('exceptions/404');
 }
}
public function load_pnr_result($pnr){
    
   if($this->session->userdata('pnr_no')){
      $this->db->select('*');
   

    $this->db->where('pnr',$pnr);
    $query = $this->db->get('pnr');
    $data=$query->row();
    $this->load->view('user/user_pnr_result',$data);
}else{
  $this->load->view('exceptions/404');
}

}
   public function get_availability(){
    if(isset($_POST['holiday_home'])){
$holiday_home=$_POST['holiday_home'];
$this->load->model('user_model');
$response=$this->user_model->get_availability($holiday_home);
if($response=="failed"){
echo "failed";
}else if($response=="success"){
$this->session->set_userdata('HH',$holiday_home);
echo "success";
}
    }else{
   $this->load->view('exceptions/404');       
    }
   }
   public function load_afterBook_form(){
    if($this->session->userdata('HH')){
        $this->db->select('*');
   $this->db->where('pnr',$this->session->userdata('pnr_no'));
    $query = $this->db->get('pnr');
    $data=$query->row();
        $this->load->view('user/user_after_book',$data);
    }
   }
 public function check_availability(){
    if($this->session->userdata('HH')){
        
        $bsd=$_POST['bsd'];
        $bsm=$_POST['bsm'];
        $bsy=$_POST['bsy'];
        $bed=$_POST['bed'];
        $bem=$_POST['bem'];
        $bey=$_POST['bey'];
        $people=$_POST['people'];
        $home_holiday=$_POST['home_holiday'];
        $grade=$_POST['grade'];
        $this->load->model('user_model');
        $res=$this->user_model->check_availability($bsd,$bsm,$bsy,$bed,$bem,$bey,$people,$home_holiday,$grade);
        if($res="failed"){
            echo "failed";
        }
    }
 }

}