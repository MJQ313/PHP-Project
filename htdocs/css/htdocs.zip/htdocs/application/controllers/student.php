<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Student extends CI_Controller {
    public function index()
    {
        $this->load->view('student/home');
    }
     public function student_enroll()
     {
         $this->load->view('student/enroll');
     }
     public function solosport()
     {
       
         $this->db->select('event');
         $this->db->from('solospt');
         $query=$this->db->get();
         $data['events']=$query->result();
         $this->load->view('student/indsport',$data);
        
     }
     public function teamsport()
     {
       
         $this->db->select('event,players');
         $this->db->from('teamspt');
         $query=$this->db->get();
         $data['events']=$query->result();
         $this->load->view('student/teamsport',$data);
        
     }
     public function teamsportextend()
     {
       
        
         $this->load->view('student/teamsportenroll');
        
     }
     public function soloother()
     {
       
         $this->db->select('event');
         $this->db->from('solooth');
         $query=$this->db->get();
         $data['events']=$query->result();
         $this->load->view('student/solooth',$data);
        
     }
    public function enroll_solosport()
    {
        if(isset($_POST['name']) || isset($_POST['branch']) || isset($_POST['year']) || isset($_POST['event']) || isset($_POST['mobile'])){
            
        
             $name=$_POST['name'];
        $branch=$_POST['branch'];
         $year=$_POST['year'];
             $event=$_POST['event'];
             $mobile=$_POST['mobile'];
        $this->load->model('student_model');
        $enroll=$this->student_model->enroll_solosport($name,$branch,$year,$event,$mobile);
             if($enroll=="failed")
        {
            echo "failed";
        }
        else if($enroll="success")
        {
          
            echo "success";
        }
        
    }
    }
     public function load_notifications(){
        $this->db->select('notification');
         $this->db->from('notify');
         $query=$this->db->get();
         $data['notifications']=$query->result();
        $this->load->view('student/view_notifications',$data);
    }
    public function enroll_soloother()
    {
        if(isset($_POST['name']) || isset($_POST['branch']) || isset($_POST['year']) || isset($_POST['event']) || isset($_POST['mobile'])){
        
             $name=$_POST['name'];
        $branch=$_POST['branch'];
         $year=$_POST['year'];
             $event=$_POST['event'];
             $mobile=$_POST['mobile'];
        $this->load->model('student_model');
        $enroll=$this->student_model->enroll_soloother($name,$branch,$year,$event,$mobile);
             if($enroll=="failed")
        {
            echo "failed";
        }
        else if($enroll="success")
        {
          
            echo "success";
        }
        
    }
    }
      public function get_players()
    {
        if(isset($_POST['event']))
           {
        $event=$_POST['event'];
                $this->load->model('student_model');
         $players=$this->student_model->get_players($event);
               if($players=="no")
               {
                   echo "failed";
               }
               else
               {
                   $this->session->set_userdata('plcount',$players);
                    $this->session->set_userdata('eventname',$event);
               }
         
    }
    
           

           }
 public function enroll_teamsport()
    { 
        if(isset($_POST['teamname']) || isset($_POST['event']))
        {
        $teamname=$_POST['teamname'];
        $event=$_POST['event'];
        $this->load->model('student_model');
        $response=$this->student_model->create_teamsport($teamname,$event);
         if($response=="no")
               {
                   echo "failed";
               }
               else
               {
                   echo "success";
               }
        
    }
        
    }
}