<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class View_Major extends CI_Controller {
    public function index()
    {
        $this->load->view('login/view_major');
    }
     public function load_login()
    {
        $this->load->view('login/view_login');
    }
     public function load_home()
    {
        
         $this->db->select('event');
         $this->db->from('solospt');
         $query=$this->db->get();
        $c1=$query->num_rows();
         $data['events']=$query->result();
           $this->db->select('event');
         $this->db->from('teamspt');
         $query=$this->db->get();
        $c2=$query->num_rows();
         $data['events1']=$query->result();
        $this->db->select('event');
         $this->db->from('solooth');
         $query=$this->db->get();
        $c3=$query->num_rows();
         $data['events2']=$query->result();
         $this->db->select('event');
         $this->db->from('teamoth');
         $query=$this->db->get();
        $c4=$query->num_rows();
         $data['events3']=$query->result();
         $this->db->select('notification');
         $this->db->from('notify');
         $query=$this->db->get();
         $data['notifications']=$query->result();
        $c=$c1+$c2+$c3+$c4;
        $this->session->set_userdata('eventcount',$c);
        $this->load->view('login/view_home',$data);
    }
    public function load_profile()
    {
        
        $this->load->view('login/view_profile');
    }
      public function logout()
    {
        $this->session->unset_userdata('user_id');
        echo "logout";
    }
     public function load_signup()
    {
        $this->load->view('signup/view_signup');
    }
    public function login()
    {if(isset($_POST['username']) || isset($_POST['password'])){
        $username=$_POST['username'];
         $password=$_POST['password'];
        $this->load->model('view_model');
        $login=$this->view_model->login($username,$password);
        if($login=="no")
        {
            echo "failed";
        }
        else
        {
           $this->session->set_userdata ('user_id',$login);
            
            echo "success";
        }
    }
    }
     public function signup()
    {if(isset($_POST['firstname']) || isset($_POST['lastname']) || isset($_POST['username']) || isset($_POST['password']))
        $name=$_POST['firstname']." ".$_POST['lastname'];
         
        $username=$_POST['username'];
         $password=$_POST['password'];
        $this->load->model('view_model');
        $signup=$this->view_model->signup($name,$username,$password);
        if($signup=="failed")
        {
            echo "failed";
        }
        else if($signup="success")
        {
          
            echo "success";
        }
    
    }
    public function profile()
    {
        if(isset($_POST['name']) || isset($_POST['username']) || isset($_POST['email']) || isset($_POST['password'])){
            $name=$_POST['name'];
            $username=$_POST['username'];
            $email=$_POST['email'];
            $password=$_POST['password'];
            $this->load->model('view_model');
             $update=$this->view_model->update($name,$username,$email,$password);
            if($update=="failed")
        {
            echo "failed";
        }
        else if($update="success")
        {
           $this->db->select('id,name,username,password');
        $this->db->where('id',$this->session->userdata('user_id'));
        $query=$this->db->get('users');
        $row=$query->row();
        $this->session->set_userdata('username',$row->username);
         $this->session->set_userdata('name',$row->name);
         $this->session->set_userdata('password',$row->password);
         $this->session->set_userdata('email',$row->email);
            echo "success";
        }
        
    }
    }
    public function addsolospt(){
        if(isset($_POST['eventname'])){
            $eventname=$_POST['eventname'];
            $this->load->model('view_model');
            $add=$this->view_model->addsolospt($eventname);
              if($add=="failed")
        {
            echo "failed";
        }
        else if($add="success")
        {
          
            echo "success";
        }
            
        }
    }
     public function addsolooth(){
        if(isset($_POST['eventname'])){
            $eventname=$_POST['eventname'];
            $this->load->model('view_model');
            $add=$this->view_model->addsolooth($eventname);
              if($add=="failed")
        {
            echo "failed";
        }
        else if($add="success")
        {
          
            echo "success";
        }
            
        }
    }
     public function addteamspt(){
        if(isset($_POST['eventname']) || isset($_POST['par'])){
            $eventname=$_POST['eventname'];
            $par=$_POST['par'];
            $this->load->model('view_model');
            $add=$this->view_model->addteamspt($eventname,$par);
              if($add=="failed")
        {
            echo "failed";
        }
        else if($add="success")
        {
          
            echo "success";
        }
            
        }
    }
    public function addteamoth(){
        if(isset($_POST['eventname'])){
            $eventname=$_POST['eventname'];
            $this->load->model('view_model');
            $add=$this->view_model->addteamoth($eventname);
              if($add=="failed")
        {
            echo "failed";
        }
        else if($add="success")
        {
          
            echo "success";
        }
            
        }
    }
     public function rmsolospt(){
        if(isset($_POST['spevent1'])){
            $spevent1=$_POST['spevent1'];
            $this->load->model('view_model');
            $rm=$this->view_model->rmsolospt($spevent1);
              if($rm=="failed")
        {
            echo "failed";
        }
        else if($rm="success")
        {
          
            echo "success";
        }
            
        }
    }
    public function rmteamspt(){
        if(isset($_POST['spevent2'])){
            $spevent2=$_POST['spevent2'];
            $this->load->model('view_model');
            $rm=$this->view_model->rmteamspt($spevent2);
              if($rm=="failed")
        {
            echo "failed";
        }
        else if($rm="success")
        {
          
            echo "success";
        }
            
        }
    }
   public function rmsolooth(){
        if(isset($_POST['spevent3'])){
            $spevent3=$_POST['spevent3'];
            $this->load->model('view_model');
            $rm=$this->view_model->rmsolooth($spevent3);
              if($rm=="failed")
        {
            echo "failed";
        }
        else if($rm="success")
        {
          
            echo "success";
        }
            
        }
    }
     public function rmteamoth(){
        if(isset($_POST['spevent4'])){
            $spevent4=$_POST['spevent4'];
            $this->load->model('view_model');
            $rm=$this->view_model->rmteamoth($spevent4);
              if($rm=="failed")
        {
            echo "failed";
        }
        else if($rm="success")
        {
          
            echo "success";
        }
            
        }
    }
    public function manageevent()
    {
        if(isset($_POST['passmanage']))
        {
            $passmanage=$_POST['passmanage'];
            if(md5($passmanage)=="0cd33b750d611f641c76aa863d927454"){
                echo "success";
            }else
            {
                echo "failed";
            }
        }
    }
     public function liststudent()
    {
        if(isset($_POST['passstudent']))
        {
            $passstudent=$_POST['passstudent'];
            if(md5($passstudent)=="0cd33b750d611f641c76aa863d927454"){
                echo "success";
            }else
            {
                echo "failed";
            }
        }
    }
     public function notify()
    {
        if(isset($_POST['passnotify']))
        {
            $passnotify=$_POST['passnotify'];
            if(md5($passnotify)=="0cd33b750d611f641c76aa863d927454"){
                echo "success";
            }else
            {
                echo "failed";
            }
        }
    }
    public function listsolospt(){
        if(isset($_POST['stdevent1'])){
            $stdevent1=$_POST['stdevent1'];
            $this->load->model('view_model');
            $list=$this->view_model->listsolospt($stdevent1);
            if($list=="failed")
            {
                echo "failed";
            }
            else
            {
                $this->session->set_userdata('listingvar',$stdevent1);
                echo "success";
            }
            
        }
    }
     public function listteamspt(){
        if(isset($_POST['stdevent2'])){
            $stdevent2=$_POST['stdevent2'];
            $this->load->model('view_model');
            $list=$this->view_model->listteamspt($stdevent2);
            if($list=="failed")
            {
                echo "failed";
            }
            else
            {
                $this->session->set_userdata('listingvar',$stdevent2);
                echo "success";
            }
            
        }
    }
     public function listsolooth(){
        if(isset($_POST['stdevent3'])){
            $stdevent3=$_POST['stdevent3'];
            $this->load->model('view_model');
            $list=$this->view_model->listsolooth($stdevent3);
            if($list=="failed")
            {
                echo "failed";
            }
            else
            {
                $this->session->set_userdata('listingvar',$stdevent3);
                echo "success";
            }
            
        }
    }
      public function listteamoth(){
        if(isset($_POST['stdevent4'])){
            $stdevent4=$_POST['stdevent4'];
            $this->load->model('view_model');
            $list=$this->view_model->listteamoth($stdevent4);
            if($list=="failed")
            {
                echo "failed";
            }
            else
            {
                $this->session->set_userdata('listingvar',$stdevent4);
                echo "success";
            }
            
        }
    }
    public function loadlistsolospt(){
        $eventname=$this->session->userdata('listingvar');
        $this->db->select('name,branch,year,mobile');
        $this->db->from('solosptpart');
        $this->db->where('event',$eventname);
        $query=$this->db->get();
        $data=$query->result();
       $this->session->set_userdata('listarray',$data);
        $this->load->view("login/view_student_list");
        
    }
     public function loadlistteamspt(){
        $eventname=$this->session->userdata('listingvar');
        $this->db->select('name,branch,year,mobile');
        $this->db->from('teamsptpart');
        $this->db->where('event',$eventname);
        $query=$this->db->get();
        $data=$query->result();
       $this->session->set_userdata('listarray',$data);
        $this->load->view("login/view_student_list");
        
    }
     public function loadlistsolooth(){
        $eventname=$this->session->userdata('listingvar');
        $this->db->select('name,branch,year,mobile');
        $this->db->from('soloothpart');
        $this->db->where('event',$eventname);
        $query=$this->db->get();
        $data=$query->result();
       $this->session->set_userdata('listarray',$data);
        $this->load->view("login/view_student_list");
        
    }
      public function loadlistteamoth(){
        $eventname=$this->session->userdata('listingvar');
        $this->db->select('name,branch,year,mobile');
        $this->db->from('teamothpart');
        $this->db->where('event',$eventname);
        $query=$this->db->get();
        $data=$query->result();
       $this->session->set_userdata('listarray',$data);
        $this->load->view("login/view_student_list");
        
    }
    public function student_list_pdf(){
        $this->load->view('login/view_student_list_pdf');
    }
   
    public function add_notification(){
        if(isset($_POST['notification'])){
            $notification=$_POST['notification'];
            $this->load->model('view_model');
            $result=$this->view_model->add_notification($notification);
            if($result=="failed")
            {
                echo "failed";
            }
            else
            {
                echo "success";
            }
            
        }
    }
     public function remove_notification(){
        if(isset($_POST['notificationremove'])){
            $notificationremove=$_POST['notificationremove'];
            $this->load->model('view_model');
            $result=$this->view_model->remove_notification($notificationremove);
            if($result=="failed")
            {
                echo "failed";
            }
            else
            {
                echo "success";
            }
            
        }
    }
  
}