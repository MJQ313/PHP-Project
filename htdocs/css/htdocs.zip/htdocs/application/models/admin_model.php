<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin_Model extends CI_Model {
     function __construct()
    {
        parent:: __construct();
        $this->load->database();
        
    }
   function login_process($username,$password)
    {
        $this->db->select('id,adminid,adminpass');
$this->db->where('adminid', $username);
$this->db->where('adminpass', $password);

$query = $this->db->get('admin');
         $data=$query->result_array();
         if(empty($data))
            {
                $res="failed";
                return $res;
            }
            else
            {
              
    
                 return $username;
           
            }
    } 
}
?>