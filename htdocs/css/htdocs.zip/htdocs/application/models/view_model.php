<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class View_Model extends CI_Model {
     function __construct()
    {
        parent:: __construct();
        $this->load->database();
        
    }
    function login($username,$password){
        $this->db->select('id,username,password');
$this->db->where('username', $username);
$this->db->where('password', $password);

$query = $this->db->get('users');
         $data=$query->result_array();
         if(empty($data))
            {
                $res="no";
                return $res;
            }
            else
            {
              $res=$data[0]['id'];
    
                 return $res;
           
            }
    }
    function signup($name,$username,$password){
        $this->db->select('id');
        $this->db->where('username',$username);
         $query = $this->db->get('users');
        $data=$query->result_array();
        if(empty($data))
            {
                 $data = array("name"=>$name,"username"=>$username,"password"=>$password);
       $query= $this->db->insert('users',$data);
                
        if($query)
        {
            $res="success";
        }
        return $res;
            }else
            {
                $res="failed";
                return $res;
            }
       
     
    }
   function update($name,$username,$email,$password){
      $data=array("name"=>$name,"username"=>$username,"email_id"=>$email,"password"=>$password);
       $query= $this->db->insert('users',$data);
                
        if($query)
        {
            $res="success";
            return $res;
        }
        else
        {
                $res="failed";
                return $res;
    }
       
     
    }
    public function addsolospt($eventname)
    {
          $this->db->select('id');
        $this->db->where('event',$eventname);
         $query = $this->db->get('solospt');
        $data=$query->result_array();
         if(empty($data))
            {
                 $data = array("event"=>$eventname);
       $query= $this->db->insert('solospt',$data);
                
        if($query)
        {
            $res="success";
        }
        return $res;
            }else
            {
                $res="failed";
                return $res;
            }
       
    }
      public function addsolooth($eventname)
    {
          $this->db->select('id');
        $this->db->where('event',$eventname);
         $query = $this->db->get('solooth');
        $data=$query->result_array();
         if(empty($data))
            {
                 $data = array("event"=>$eventname);
       $query= $this->db->insert('solooth',$data);
                
        if($query)
        {
            $res="success";
        }
        return $res;
            }else
            {
                $res="failed";
                return $res;
            }
       
    }
     public function addteamspt($eventname,$par)
    {
          $this->db->select('id');
        $this->db->where('event',$eventname);
         $query = $this->db->get('teamspt');
        $data=$query->result_array();
         if(empty($data))
            {
                 $data = array("event"=>$eventname,"players"=>$par);
       $query= $this->db->insert('teamspt',$data);
                
        if($query)
        {
            $res="success";
        }
        return $res;
            }else
            {
                $res="failed";
                return $res;
            }
       
    }
         public function addteamoth($eventname)
    {
          $this->db->select('id');
        $this->db->where('event',$eventname);
         $query = $this->db->get('teamoth');
        $data=$query->result_array();
         if(empty($data))
            {
                 $data = array("event"=>$eventname);
       $query= $this->db->insert('teamoth',$data);
                
        if($query)
        {
            $res="success";
        }
        return $res;
            }else
            {
                $res="failed";
                return $res;
            }
       
    }
     public function rmsolospt($spevent1)
    {
          $this->db->select('id');
        $this->db->where('event',$spevent1);
         $query = $this->db->get('solospt');
        $data=$query->result_array();
        if(empty($data)){
             $res="failed";
                return $res;
        }else{
        $this->db->where('event',$spevent1);
         $data=$this->db->delete('solospt');
         if($data)
            {
                 $res="success";
        
        return $res;
            }
        else
        {
             $res="failed";
                return $res;
        }
       
       
    }}
     public function rmteamspt($spevent2)
    {
          $this->db->select('id');
        $this->db->where('event',$spevent2);
         $query = $this->db->get('teamspt');
        $data=$query->result_array();
        if(empty($data)){
             $res="failed";
                return $res;
        }else{
        $this->db->where('event',$spevent2);
         $data=$this->db->delete('teamspt');
         if($data)
            {
                 $res="success";
        
        return $res;
            }
        else
        {
             $res="failed";
                return $res;
        }
       
       
    }}
      public function rmsolooth($spevent3)
    {
          $this->db->select('id');
        $this->db->where('event',$spevent3);
         $query = $this->db->get('solooth');
        $data=$query->result_array();
        if(empty($data)){
             $res="failed";
                return $res;
        }else{
        $this->db->where('event',$spevent3);
         $data=$this->db->delete('solooth');
         if($data)
            {
                 $res="success";
        
        return $res;
            }
        else
        {
             $res="failed";
                return $res;
        }
       
       
    }}
     public function rmteamoth($spevent4)
    {
          $this->db->select('id');
        $this->db->where('event',$spevent4);
         $query = $this->db->get('teamoth');
        $data=$query->result_array();
        if(empty($data)){
             $res="failed";
                return $res;
        }else{
        $this->db->where('event',$spevent4);
         $data=$this->db->delete('teamoth');
         if($data)
            {
                 $res="success";
        
        return $res;
            }
        else
        {
             $res="failed";
                return $res;
        }
       
       
    }}
    public function listsolospt($stdevent1)
    {
          $this->db->select('id');
         $this->db->where('event',$stdevent1);
         $query = $this->db->get('solosptpart');
         $data=$query->result_array();
        if(empty($data)){
             $res="failed";
                return $res;
        }else
        {
             $res="success";
                return $res;
        }
    }
     public function listteamspt($stdevent2)
    {
          $this->db->select('id');
         $this->db->where('event',$stdevent2);
         $query = $this->db->get('teamsptpart');
         $data=$query->result_array();
        if(empty($data)){
             $res="failed";
                return $res;
        }else
        {
             $res="success";
                return $res;
        }
    }
     public function listsolooth($stdevent3)
    {
          $this->db->select('id');
         $this->db->where('event',$stdevent3);
         $query = $this->db->get('soloothpart');
         $data=$query->result_array();
        if(empty($data)){
             $res="failed";
                return $res;
        }else
        {
             $res="success";
                return $res;
        }
    }
      public function listteamoth($stdevent4)
    {
          $this->db->select('id');
         $this->db->where('event',$stdevent4);
         $query = $this->db->get('teamothpart');
         $data=$query->result_array();
        if(empty($data)){
             $res="failed";
                return $res;
        }else
        {
             $res="success";
                return $res;
        }
    }
          public function add_notification($notification)
    {
          $this->db->select('id');
        $this->db->where('notification',$notification);
         $query = $this->db->get('notify');
        $data=$query->result_array();
         if(empty($data))
            {
                 $data = array("notification"=>$notification);
       $query= $this->db->insert('notify',$data);
                
        if($query)
        {
            $res="success";
        }
        return $res;
            }else
            {
                $res="failed";
                return $res;
            }
       
    }
     public function remove_notification($notificationremove)
    {
          $this->db->select('id');
        $this->db->where('notification',$notificationremove);
         $query = $this->db->get('notify');
        $data=$query->result_array();
        if(empty($data)){
             $res="failed";
                return $res;
        }else{
        $this->db->where('notification',$notificationremove);
         $data=$this->db->delete('notify');
         if($data)
            {
                 $res="success";
        
        return $res;
            }
        else
        {
             $res="failed";
                return $res;
        }
       
       
    }}
}
?>