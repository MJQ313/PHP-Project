<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Student_Model extends CI_Model {
     function __construct()
    {
        parent:: __construct();
        $this->load->database();
        
    }
    function get_players($event){
        $this->db->select('players');
$this->db->where('event', $event);


$query = $this->db->get('teamspt');
         $data=$query->row();
         if(empty($data))
            {
                $res="no";
                return $res;
            }
            else
            {
              $res=$data->players;
    
                 return $res;
           
            }
    }
    function enroll_solosport($name,$branch,$year,$event,$mobile){
        $this->db->select('id');
        $this->db->where('name',$name);
         $this->db->where('event',$event);
         $query = $this->db->get('solosptpart');
        $data=$query->result_array();
        if(empty($data))
            {
                 $data = array("name"=>$name,"branch"=>$branch,"year"=>$year,"event"=>$event,"mobile"=>$mobile);
       $query= $this->db->insert('solosptpart',$data);
                
        if($query)
        {
            $res="success";
        }
        return $res;
            }else
            {
                $res="failed";
                return $res;
            }
       
     
    }
   function enroll_soloother($name,$branch,$year,$event,$mobile){
        $this->db->select('id');
        $this->db->where('name',$name);
         $this->db->where('event',$event);
         $query = $this->db->get('soloothpart');
        $data=$query->result_array();
        if(empty($data))
            {
                 $data = array("name"=>$name,"branch"=>$branch,"year"=>$year,"event"=>$event,"mobile"=>$mobile);
       $query= $this->db->insert('soloothpart',$data);
                
        if($query)
        {
            $res="success";
        }
        return $res;
            }else
            {
                $res="failed";
                return $res;
            }
       
     
    }
     function create_teamsport($teamname,$event){
       $this->db->select('id');
        $this->db->where('teamname',$teamname);
         $this->db->where('event',$event);
         $query = $this->db->get('teamsptpart');
        $data=$query->result_array();
         if(empty($data))
            {
                 $this->db->select('players');
       
         $this->db->where('event',$event);
         $query = $this->db->get('teamspt');
                 $data=$query->row();
                $players=$data->players;
                 $data = array("teamname"=>$teamname,"event"=>$event,'players'=>$players);
       $query= $this->db->insert('teamsptpart',$data);
              
        if($query)
        {
            $res="success";
        }
        return $res;
            }else
            {
                $res="no";
                return $res;
            }
            
    }
   
}
?>