<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class View_Model extends CI_Model {
     function __construct()
    {
        parent:: __construct();
        $this->load->database();
        
    }
    function login($username,$password)
    {
        $this->db->select('id,username,password');
$this->db->where('username', $username);
$this->db->where('password', $password);

$query = $this->db->get('coadmin');
         $data=$query->result_array();
         if(empty($data))
            {
                $res="no";
                return $res;
            }
            else
            {
              $res=$data[0]['id'];
    
                 return $res;
           
            }
    }
    
}
?>