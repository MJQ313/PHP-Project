<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<base href="<?php echo base_url();?>">
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="<?php base_url();?>/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php base_url();?>/css/animate.min.css">
	<title>Hackthon</title>
</head>
<body>
<nav class="navbar navbar-toggleable-md navbar-light bg-success">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="user/index">Hackathon</a>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="user/login">Login</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="user/register">Register</a>
      </li>
     
    </ul>
  </div>
</nav>
<div class="container-fluid">
   <div class="row">
  <div class="col-md-12">
    <div class="jumbotron">

    <div class="col-md-6 offset-md-3">
      <blockquote><h3 style="font-family: arial;">Employee Registration</h3></blockquote>
      <form>
  <div class="form-group">
    <label for="EmployeeId">Employee Id</label>
    <input type="text" class="form-control" id="EmployeeId" aria-describedby="EmployeeIdHelp" placeholder="Enter Your Employee Id">
    <small id="EmployeeIdHelp" class="form-text text-muted">We'll never share your information with anyone else.</small>
  </div>
   <div class="form-group">
    <label for="MobileNo">Mobile Number</label>
    <input type="text" class="form-control" id="MobileNo" placeholder="Enter Your Mobile Number" aria-describedby="MobileNoHelp">
    <small id="MobileNoHelp" class="form-text text-muted">Enter Mobile No associated with your employee acoount.</small>
  </div>
   <div class="form-group">
    <label for="Email">Email</label>
    <input type="text" class="form-control" id="Email" placeholder="Enter Your Email">

  </div>
 
  <button type="submit" class="btn btn-primary">Proceed</button>
</form>
    </div>
    </div>
  </div>
 </div>

</div>
<nav class="navbar fixed-bottom navbar-light bg-faded">
  <div class="navbar-brand">&copy; Ministry Of Railways , India.</div>
</nav>

	<script src="<?php base_url();?>/js/jquery.js"></script>
	<script src="<?php base_url();?>/js/bootstrap.min.js"></script>
    <script src="<?php base_url();?>/js/register.js"></script>
</body>
</html>