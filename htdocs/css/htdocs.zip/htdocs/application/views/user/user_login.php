<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
if($this->session->userdata('sess_id')){
  redirect('user/login_home');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<base href="<?php echo base_url();?>">
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="<?php base_url();?>/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php base_url();?>/css/animate.min.css">
<link rel="stylesheet" href="<?php base_url();?>/css/toastr.min.css">
	<title>Hackthon</title>
</head>
<body>
<nav class="navbar navbar-toggleable-md navbar-light bg-success">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#">Hackathon</a>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="user/login">Login</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="user/register">Register</a>
      </li>
     
    </ul>
  </div>
</nav>
<div class="container-fluid">
  <div class="row">
  <div class="col-md-12">
    <div class="jumbotron">
  <div class="col-md-6 offset-md-3">
      <blockquote><h3 style="font-family: arial;">Employee Login</h3></blockquote>
      <form>
  <div class="form-group" id="emid_group">
    <label for="EmployeeId">Employee Id</label>
    <input type="text" class="form-control" id="EmployeeId"  placeholder="Enter Your Employee Id"><small class="form-control-feedback" id="emid_fb"></small>
   
  </div>
  <div class="form-group" id="pass_group">
    <label for="Password">Password</label>
    <input type="password" class="form-control" id="Password" placeholder="Enter Password"><small class="form-control-feedback" id="pass_fb"></small>
  </div>
  
  <button type="submit" class="btn btn-primary" id="login">Login</button>
</form>

  </div>
    </div>
  </div>
 </div>
</div>

<nav class="navbar fixed-bottom navbar-light bg-faded">
  <div class="navbar-brand">&copy; Ministry Of Railways , India.</div>
</nav>

	<script src="<?php base_url();?>/js/jquery.js"></script>
	<script src="<?php base_url();?>/js/bootstrap.min.js"></script>
  <script src="<?php base_url();?>/js/toastr.min.js"></script>
  <script>
    $(document).ready(function(){
      $("#login").click(function(event){
        event.preventDefault();
        if($("#EmployeeId").val()==""){
          $("#pass_group").removeClass('has-danger');
            $("#pass_fb").html('');
          $("#emid_group").addClass('has-danger');
          $("#emid_fb").html('Employee Id cannot be empty');
              }else 
        if($("#Password").val()==""){
           $("#emid_group").removeClass('has-danger');
            $("#emid_fb").html('');
          $("#pass_group").addClass('has-danger');
          $("#pass_fb").html('Password cannot be empty');
          

        }else{
          $("#pass_group").removeClass('has-danger');
            $("#pass_fb").html('');
            $("#emid_group").removeClass('has-danger');
            $("#emid_fb").html('');
           
              $.ajax({
                        url: "user/login_process"
                        , type: "POST"
                        , data: {
                            emid: $("#EmployeeId").val()
                            , pass: $("#Password").val()
                        },beforeSend:function(){
                     $("#login").html('Logging In');
                        }
                        , success: function (data) {
                            if (data == "failed") {
                         $("#login").html('Login');
                            toastr['error']("Incorrect Credentials !")
                    toastr.options = {
                        "closebutton": false
                        , "debug": false
                        , "newestOnTop": false
                        , "progressBar": true
                        , "positionClass": "toast-top-right"
                        , "preventDuplicates": false
                        , "onclick": null
                        , "showDuration": "300"
                        , "hideDuration": "1000"
                        , "timeOut": "5000"
                        , "extendedTimeOut": "1000"
                        , "showEasing": "swing"
                        , "hideEasing": "linear"
                        , "showMethod": "fadeIn"
                        , "hideMethod": "fadeOut"
                    }
                            }
                            else if (data == "success") {
                         $("#login").html('Taking you to Employee Home');
                         window.location.href="user/login_home";
                                
                            }
                        }
                    });
        }

      });
    });
  </script>
</body>
</html>