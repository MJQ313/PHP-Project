<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
if(!$this->session->userdata('sess_id')){
  redirect('user/login');
}$pnr_no=$this->session->userdata('pnr_no');
   $data_pnr=$this->db->select('*')->from('pnr')->where('pnr',$pnr_no)->get()->row();

   
?>
<!DOCTYPE html>
<html lang="en">
<head>
<base href="<?php echo base_url();?>">
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="<?php base_url();?>/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php base_url();?>/css/animate.min.css">
<link rel="stylesheet" href="<?php base_url();?>/css/toastr.min.css">
	<title>Hackthon | PNR Results</title>
</head>
<body>
<nav class="navbar navbar-toggleable-md navbar-light bg-success">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#">Hackathon</a>
  <div class="collapse navbar-collapse" id="navbarNav">
     <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" href="user/login_home_">Home</a>
      </li>
    
     
    </ul>
  </div>
</nav>

<div class="container-fluid">
  <div class="jumbotron">
    <div class="row">
    <div id="afterBook" class="col-md-12">
    <blockquote><h5>Basic Booking Form Info </h5></blockquote><hr>

 
   
     <div class="row">
     <blockquote><h6> &nbsp;&nbsp;&nbsp;Start Date : <?php echo $jed."-".$jem."-".$jey;?></h6></blockquote>
     <input type="hidden" id="start_day" value="<?php echo $data_pnr->jed;?>">
   
   
      <input type="hidden" id="start_month" value="<?php echo $data_pnr->jem;?>">
      <input type="hidden" id="grade" value="<?php echo $this->session->userdata('gr')?>">
  
     <input type="hidden" id="start_year" value="<?php echo $data_pnr->jey;?>">
      <input type="hidden" id="home_holiday" value="<?php echo $this->session->userdata('HH');?>">
 </div>
<div class="row">
   <div class="col-md-2" id="end_day_group">
     <label for="end_day">End Date Day</label>
     <input type="number" class="form-control" placeholder="Enter Day" id="end_day">
   <small class="form-control-feedback" id="end_day_fb"></small>
   </div>
   <div class="col-md-2" id="end_month_group">
     <label for="end_month">End Date Month</label>
     <input type="number" class="form-control" placeholder="Enter Month" id="end_month">
   <small class="form-control-feedback" id="end_month_fb"></small>
   </div>
   <div class="col-md-2" id="end_year_group">
     <label for="end_year">End Date Year</label>
     <input type="number" class="form-control" placeholder="Enter Year" id="end_year">
     <small class="form-control-feedback" id="end_year_fb"></small>

   </div>
   
 </div>
<div class="row">
     <div class="col-md-4" id="people_group">
     <label for="people">Enter No of Persons</label>
     <input type="number" class="form-control" placeholder="Enter No of Persons" id="people">
     <small class="form-control-feedback" id="people_fb"></small>
   </div>
  
   </div>
<div class="row">
   <div class="col-md-4"><br>
     <button class="btn btn-outline-success" id="check_avail" type="button">Check Availability</button>
   </div>
</div>
</div>
</div></div></div>
   
  
<nav class="navbar fixed-bo'ttom navbar-light bg-faded">
  <div class="navbar-brand">&copy; Ministry Of Railways , India.</div>
</nav>

	<script src="<?php base_url();?>/js/jquery.js"></script>
	<script src="<?php base_url();?>/js/bootstrap.min.js"></script>
  <script src="<?php base_url();?>/js/toastr.min.js"></script>
  <script> 
$(document).ready(function(){

$("#check_avail").click(function(event){
  event.preventDefault();
  if($("#start_day").val()>31 || $("#start_day").val()<=0 || $("#start_day").val()==""){
    $("#end_day_group").removeClass('has-danger');
    $("#end_day_fb").html('');
     $("#end_month_group").removeClass('has-danger');
    $("#end_month_fb").html('');
     $("#end_year_group").removeClass('has-danger');
    $("#end_year_fb").html('');
    $("#people_group").removeClass('has-danger');
    $("#people_fb").html('');
  }else if($("#start_month").val()>12 || $("#start_month").val()<=0 || $("#start_month").val()==""){
     $("#end_day_group").removeClass('has-danger');
    $("#end_day_fb").html('');
     $("#end_month_group").removeClass('has-danger');
    $("#end_month_fb").html('');
     $("#end_year_group").removeClass('has-danger');
    $("#end_year_fb").html('');
    $("#people_group").removeClass('has-danger');
    $("#people_fb").html('');
  }else if($("#start_year").val()>2020 || $("#start_year").val()<=2016 || $("#start_month").val()==""){
     $("#end_day_group").removeClass('has-danger');
    $("#end_day_fb").html('');
     $("#end_month_group").removeClass('has-danger');
    $("#end_month_fb").html('');
     $("#end_year_group").removeClass('has-danger');
    $("#end_year_fb").html('');
    $("#people_group").removeClass('has-danger');
    $("#people_fb").html('');
  }else if($("#end_day").val()>31 || $("#end_day").val()<=0 || $("#end_day").val()==""){
     $("#end_day_group").addClass('has-danger');
    $("#end_day_fb").html('Enter valid date');
     $("#end_month_group").removeClass('has-danger');
    $("#end_month_fb").html('');
     $("#end_year_group").removeClass('has-danger');
    $("#end_year_fb").html('');
    $("#people_group").removeClass('has-danger');
    $("#people_fb").html('');
  }else if($("#end_month").val()>12 || $("#end_month").val()<=0 || $("#end_month").val()==""){
     $("#end_day_group").removeClass('has-danger');
    $("#end_day_fb").html('');
     $("#end_month_group").addClass('has-danger');
    $("#end_month_fb").html('Enter valid month');
     $("#end_year_group").removeClass('has-danger');
    $("#end_year_fb").html('');
    $("#people_group").removeClass('has-danger');
    $("#people_fb").html('');
  }else if($("#end_year").val()>2020 || $("#end_year").val()<=2016 || $("#end_month").val()==""){
     $("#end_day_group").removeClass('has-danger');
    $("#end_day_fb").html('');
     $("#end_month_group").removeClass('has-danger');
    $("#end_month_fb").html('');
     $("#end_year_group").addClass('has-danger');
    $("#end_year_fb").html('Enter Valid Year');
    $("#people_group").removeClass('has-danger');
    $("#people_fb").html('');
  }else if($("#people").val()<=0 || $("#people").val()==""){
     $("#end_day_group").removeClass('has-danger');
    $("#end_day_fb").html('');
     $("#end_month_group").removeClass('has-danger');
    $("#end_month_fb").html('');
     $("#end_year_group").removeClass('has-danger');
    $("#end_year_fb").html('');
    $("#people_group").addClass('has-danger');
    $("#people_fb").html('Enter Valid Count');
  }else if($("#start_day").val()==$("#end_day").val()){
if($("#start_month").val()==$("#end_month").val()){
  if($("#start_year").val()==$("#end_year").val()){
   
     $("#end_day_group").removeClass('has-danger');
    $("#end_day_fb").html('');
     $("#end_month_group").removeClass('has-danger');
    $("#end_month_fb").html('');
     $("#end_year_group").removeClass('has-danger');
    $("#end_year_fb").html('');
    $("#people_group").removeClass('has-danger');
    $("#people_fb").html('');
      toastr['warning']("Start Date and End Date can not be equal")
                    toastr.options = {
                        "closebutton": false
                        , "debug": false
                        , "newestOnTop": false
                        , "progressBar": true
                        , "positionClass": "toast-top-right"
                        , "preventDuplicates": false
                        , "onclick": null
                        , "showDuration": "300"
                        , "hideDuration": "1000"
                        , "timeOut": "5000"
                        , "extendedTimeOut": "1000"
                        , "showEasing": "swing"
                        , "hideEasing": "linear"
                        , "showMethod": "fadeIn"
                        , "hideMethod": "fadeOut"
                    }
  }
}
  }else if($("#start_year").val()>$("#end_year").val()){
     $("#end_day_group").removeClass('has-danger');
    $("#end_day_fb").html('');
     $("#end_month_group").removeClass('has-danger');
    $("#end_month_fb").html('');
     $("#end_year_group").removeClass('has-danger');
    $("#end_year_fb").html('');
    $("#people_group").removeClass('has-danger');
    $("#people_fb").html('');
toastr['warning']("Start Date can not be greater than End Date")
                    toastr.options = {
                        "closebutton": false
                        , "debug": false
                        , "newestOnTop": false
                        , "progressBar": true
                        , "positionClass": "toast-top-right"
                        , "preventDuplicates": false
                        , "onclick": null
                        , "showDuration": "300"
                        , "hideDuration": "1000"
                        , "timeOut": "5000"
                        , "extendedTimeOut": "1000"
                        , "showEasing": "swing"
                        , "hideEasing": "linear"
                        , "showMethod": "fadeIn"
                        , "hideMethod": "fadeOut"
                    }
  }else if($("#start_month").val()>$("#end_month").val()){
     $("#end_day_group").removeClass('has-danger');
    $("#end_day_fb").html('');
     $("#end_month_group").removeClass('has-danger');
    $("#end_month_fb").html('');
     $("#end_year_group").removeClass('has-danger');
    $("#end_year_fb").html('');
    $("#people_group").removeClass('has-danger');
    $("#people_fb").html('');
toastr['warning']("Start Date can not be greater than End Date")
                    toastr.options = {
                        "closebutton": false
                        , "debug": false
                        , "newestOnTop": false
                        , "progressBar": true
                        , "positionClass": "toast-top-right"
                        , "preventDuplicates": false
                        , "onclick": null
                        , "showDuration": "300"
                        , "hideDuration": "1000"
                        , "timeOut": "5000"
                        , "extendedTimeOut": "1000"
                        , "showEasing": "swing"
                        , "hideEasing": "linear"
                        , "showMethod": "fadeIn"
                        , "hideMethod": "fadeOut"
                    }
  }else if($("#start_day").val()>$("#end_day").val()){
     $("#end_day_group").removeClass('has-danger');
    $("#end_day_fb").html('');
     $("#end_month_group").removeClass('has-danger');
    $("#end_month_fb").html('');
     $("#end_year_group").removeClass('has-danger');
    $("#end_year_fb").html('');
    $("#people_group").removeClass('has-danger');
    $("#people_fb").html('');
    toastr['warning']("Start Date can not be greater than End Date")
                    toastr.options = {
                        "closebutton": false
                        , "debug": false
                        , "newestOnTop": false
                        , "progressBar": true
                        , "positionClass": "toast-top-right"
                        , "preventDuplicates": false
                        , "onclick": null
                        , "showDuration": "300"
                        , "hideDuration": "1000"
                        , "timeOut": "5000"
                        , "extendedTimeOut": "1000"
                        , "showEasing": "swing"
                        , "hideEasing": "linear"
                        , "showMethod": "fadeIn"
                        , "hideMethod": "fadeOut"
                    }
  }
  else{
     $("#end_day_group").removeClass('has-danger');
    $("#end_day_fb").html('');
     $("#end_month_group").removeClass('has-danger');
    $("#end_month_fb").html('');
     $("#end_year_group").removeClass('has-danger');
    $("#end_year_fb").html('');
    $("#people_group").removeClass('has-danger');
    $("#people_fb").html('');
     $.ajax({
                        url: "user/check_availability"
                        , type: "POST"
                        , data: {
                            bsd: $("#start_day").val(),
                            bsm: $("#start_month").val(),
                            bsy: $("#start_year").val(),
                            bed: $("#end_day").val(),
                            bem: $("#end_month").val(),
                            bey: $("#end_year").val(),
                            people: $("#people").val(),
                            home_holiday: $("#home_holiday").val(),
                            grade: $("#grade").val()
                            
                        },beforeSend:function(){
                     $("#check_avail").html('Checking');
                        }
                        , success: function (data) {
                            if (data == "success") {
                              $("#check_avail").html('Check Availability');

                         
                         toastr['success']("Processiong Booking Info Form!")
                    toastr.options = {
                        "closebutton": false
                        , "debug": false
                        , "newestOnTop": false
                        , "progressBar": true
                        , "positionClass": "toast-top-right"
                        , "preventDuplicates": false
                        , "onclick": null
                        , "showDuration": "300"
                        , "hideDuration": "1000"
                        , "timeOut": "5000"
                        , "extendedTimeOut": "1000"
                        , "showEasing": "swing"
                        , "hideEasing": "linear"
                        , "showMethod": "fadeIn"
                        , "hideMethod": "fadeOut"
                    }
                         
                            }
                            else if(data == "failed"){
                             
                         $("#check_avail").html('Check Availability');
                         toastr['warning']('Failed')
                    toastr.options = {
                        "closebutton": false
                        , "debug": false
                        , "newestOnTop": false
                        , "progressBar": true
                        , "positionClass": "toast-top-right"
                        , "preventDuplicates": false
                        , "onclick": null
                        , "showDuration": "300"
                        , "hideDuration": "1000"
                        , "timeOut": "5000"
                        , "extendedTimeOut": "1000"
                        , "showEasing": "swing"
                        , "hideEasing": "linear"
                        , "showMethod": "fadeIn"
                        , "hideMethod": "fadeOut"
                    }
                    
                                 
                            }
                        }
                    }); 
  }
});
});
  </script>
</body>
</html>