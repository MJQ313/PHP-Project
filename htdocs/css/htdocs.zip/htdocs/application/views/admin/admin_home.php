<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
if(!$this->session->userdata('admin_sess_id')){
  redirect('admin/admin_login');
}$rows_reg=$this->db->select('*')->from('reg_holiday_homes')->get()->result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<base href="<?php echo base_url();?>">
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="<?php base_url();?>/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php base_url();?>/css/animate.min.css">
<link rel="stylesheet" href="<?php base_url();?>/css/toastr.min.css">
	<title>Hackthon</title>
</head>
<body>
<nav class="navbar navbar-toggleable-md navbar-light bg-success">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#">Hackathon | Admin</a>
 
</nav><div class="contanier-fluid" id="reg_holiday_homes_display">
  <div class="jumbotron">
  <div class="col-md-12">
    
     <div class="card">
     <table class="table table-striped table-responsive">
       <thead class="thead-inverse">
         <tr>
         <th>Choice No.</th>
           <th>Registration Number</th>
      <th>Holiday Home</th>  <th>City</th>
           <th>UID</th>
         <th>Password</th>
           <th colspan="8">Rooms</th>
           <th>Status</th>
      
      
           
         </tr>
         <tr>
           <th></th>
           <th></th>
           <th></th>
           <th></th>
           <th></th>
           <th></th>
           <th>AL</th>
           <th>AH</th>
           <th>BL</th>
           <th>BH</th>
           <th>CL</th>
           <th>CH</th>
           <th>DL</th>
           <th>DH</th><th></th>
         </tr>
       </thead>
       <tbody>
       <?php $i=1; foreach($rows_reg as $row){?>
       <th><?php echo $i;?></th>
       <th><?php echo $row->reg_no;?></th>
       <th><?php echo $row->holiday_home;?></th>
       <th><?php echo $row->city;?></th>
       <th><?php echo $row->uid;?></th>
       <th><?php echo $row->password;?></th>
       <th><?php echo $row->AL;?></th>
       <th><?php echo $row->AH;?></th>
       <th><?php echo $row->BL;?></th>
       <th><?php echo $row->BH;?></th>
       <th><?php echo $row->CL;?></th>
       <th><?php echo $row->CH;?></th>
       <th><?php echo $row->DL;?></th>
       <th><?php echo $row->DH;?></th>
       <th><?php echo $row->status;?></th><?php $i++;}?>
       </tbody>
     </table><br>
</div>

   
</div>
</div>
</div>

<div class="jumbotron" id="admin_init">

 <div class="col-md-8 offset-md-2"> 
   <blockquote><h5>Admin Home</h5></blockquote><hr>

   <div class="row">

     <div class="col-md-6">
      <div class="card">
  <div class="card-header">
    Holiday Homes
  </div>
  <div class="card-block">
    <h4 class="card-title">Holiday Homes Registered</h4>
    <p class="card-text">20</p>
    <div class="btn-group">
  <button type="button" class="btn btn-outline-danger" disabled="disabled">Manage Holiday Homes</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item" id="reg_holiday_home" href="#">Registered Holiday Homes</a>
    <a class="dropdown-item" href="#">Requests</a>
    <a class="dropdown-item" href="#">Fares</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#">Bookings</a>
  </div>
</div>
  </div>
</div>
    </div>
    <div class="col-md-6">
      <div class="card">
  <div class="card-header">
    Employee Users
  </div>
  <div class="card-block">
    <h4 class="card-title">Number Of Users</h4>
    <p class="card-text">100</p>
      <div class="btn-group">
  <button type="button" class="btn btn-outline-info" disabled="disabled">Manage Users</button>
  <button type="button" class="btn btn-info dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item" href="#">Approval Requests</a>
    <a class="dropdown-item" href="#">Users</a>
    <a class="dropdown-item" href="#">User Bookings</a>
    
  </div>
</div>
  </div>
</div>
    </div>
   </div>
      
</div></div>
<nav class="navbar fixed-bottom navbar-light bg-faded">
  <div class="navbar-brand">&copy; Ministry Of Railways , India.</div>
</nav>

	<script src="<?php base_url();?>/js/jquery.js"></script>
	<script src="<?php base_url();?>/js/bootstrap.min.js"></script>
  <script src="<?php base_url();?>/js/toastr.min.js"></script>
  <script>
    $(document).ready(function(){
      $("#reg_holiday_homes_display").hide();
      $("#reg_holiday_home").click(function(event){
        event.preventDefault();
$("#admin_init").hide('animated');
$("#reg_holiday_homes_display").show('animated');
      });
    });
  </script>
</body>
</html>